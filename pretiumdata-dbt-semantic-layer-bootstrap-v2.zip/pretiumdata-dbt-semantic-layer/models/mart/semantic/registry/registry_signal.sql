{{ config(
    materialized='table',
    tags=['semantic','registry','bootstrap']
) }}

select
    signal_key,
    signal_code,
    signal_name,
    signal_description,
    domain,
    taxon_code,
    logic_version,
    scoping_policy,
    status,
    refresh_cadence,
    override_policy,
    override_tier,
    split(geographic_levels, '|')         as geographic_levels,
    split(product_type_codes, '|')        as product_type_codes,
    display_label,
    is_active,
    sort_order,
    semantic_version,
    change_reason,
    source_key,
    managed_by,
    current_timestamp()                   as published_at
from {{ ref('registry_signal_seed') }}
