{{ config(
    materialized='table',
    tags=['semantic','entity','bootstrap']
) }}

select
    o.offering_key,
    o.offering_code,
    o.offering_name,
    o.vertical_key,
    v.vertical_code,
    o.offering_type,
    o.primary_product_type_code,
    split(o.product_type_codes, '|')      as product_type_codes,
    o.opco_code,
    o.is_supported_for_tear_sheet,
    iff(nullif(o.overlay_tags, '') is null, array_construct(), split(o.overlay_tags, '|')) as overlay_tags,
    parse_json(o.buy_box_criteria_json)   as buy_box_criteria,
    parse_json(o.signal_weights_json)     as signal_weights,
    parse_json(o.driver_relevance_json)   as driver_relevance,
    o.display_label,
    o.is_active,
    o.sort_order,
    to_date(o.effective_start_date)       as effective_start_date,
    to_date(o.effective_end_date)         as effective_end_date,
    o.is_current,
    o.semantic_version,
    o.change_reason,
    o.source_key,
    o.managed_by,
    current_timestamp()                   as published_at
from {{ ref('entity_offering_seed') }} o
left join {{ ref('entity_vertical') }} v
  on o.vertical_key = v.vertical_key
