{{ config(
    materialized='table',
    tags=['semantic','entity','bootstrap']
) }}

select
    vertical_key,
    vertical_code,
    vertical_name,
    vertical_category,
    capital_structure,
    display_label,
    is_active,
    sort_order,
    to_date(effective_start_date)          as effective_start_date,
    to_date(effective_end_date)            as effective_end_date,
    is_current,
    semantic_version,
    change_reason,
    source_key,
    managed_by,
    current_timestamp()                    as published_at
from {{ ref('entity_vertical_seed') }}
