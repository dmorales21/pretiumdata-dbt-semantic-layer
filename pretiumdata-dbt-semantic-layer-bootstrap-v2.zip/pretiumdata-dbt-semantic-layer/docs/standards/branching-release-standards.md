# Branching and Release Standards

## Purpose

This standard defines how `pretiumdata-dbt-semantic-layer` is developed, reviewed, promoted, and released across dev, staging, and prod.

---

## Branching model

### Protected long-lived branch

- `main` = the only production-bound branch

### Short-lived working branches

Use the following patterns:

- `feature/<ticket-or-topic>`
- `hotfix/<issue-name>`
- `release/<version>` only when a coordinated release window is needed

### Examples

- `feature/entity-offering-scd2`
- `feature/registry-signal-bootstrap`
- `hotfix/fix-exposure-policy-key`
- `release/1.1.0`

---

## Branch protection for `main`

The `main` branch should enforce:

- no direct pushes
- pull request required
- at least one approval minimum
- CI checks required before merge
- resolved conversations required before merge
- squash merge only

Recommended stronger setting for semantic-breaking work:

- two approvals when changes affect `entity_*`, `dim_*`, `bridge_*`, `registry_*`, or GitHub deployment workflows

---

## Pull request standards

Every PR should include:

1. business or architectural purpose
2. impacted semantic objects
3. whether the change is semantic-breaking
4. required downstream validation
5. rollback approach

### PR template checklist

- [ ] Model SQL updated
- [ ] schema.yml or docs updated
- [ ] tests added or updated
- [ ] registry impact reviewed
- [ ] semantic version impact reviewed
- [ ] release notes needed
- [ ] downstream consumer impact understood

---

## Environment promotion standard

### Dev

Used for:

- feature development
- local dbt builds
- rapid iteration
- unit and contract validation

Rule:

- all new work starts in dev only

### Staging

Used for:

- integrated validation
- semantic conformance checks
- release certification
- pre-production smoke testing

Rule:

- only code merged into `main` deploys to staging

### Prod

Used for:

- consumer-safe semantic objects only
- Prism-facing semantic assets
- certified semantic registries
- approved releases

Rule:

- prod deploys require manual approval

---

## Release standard

### Normal release flow

1. engineer creates feature branch
2. engineer validates in dev
3. PR opened against `main`
4. CI passes
5. PR approved and squash merged
6. merge to `main` triggers staging deploy
7. staging validation completed
8. production deployment manually approved
9. release notes captured
10. semantic version updated when required

---

## Semantic-breaking change rules

A semantic-breaking change includes changes such as:

- canonical key logic changes
- entity identity resolution changes
- geography crosswalk logic changes
- dimension code or label behavior changes that affect grouping
- lineage or registry contract changes
- exposure policy changes for downstream consumers

When semantic-breaking:

- update changelog or semantic version registry entry
- call out downstream consumer impact in PR
- require explicit reviewer acknowledgement
- do not release silently

---

## Hotfix standard

Hotfix branches are for urgent production corrections only.

Pattern:

- `hotfix/<issue-name>`

Examples:

- broken prod deployment workflow
- invalid semantic registry filter
- failing critical conformance test

Hotfix flow:

1. branch from `main`
2. validate in dev if practical
3. PR review expedited
4. deploy to staging
5. manual prod approval
6. back-document release note

---

## Naming standards

Allowed production semantic families:

- `entity_*`
- `dim_*`
- `bridge_*`
- `registry_*`
- `glossary_*`
- `explain_*`
- `retrieval_*`

Not allowed for promoted objects:

- `_v2`
- `_final`
- `_new`
- `_temp`
- `_latest`

Version belongs in metadata and registry, not in stable production object names.

---

## Minimum release evidence

Before production approval, the release should show:

- successful staging dbt build
- successful key tests
- successful relationship tests
- documentation generated
- known consumer impact documented
- rollback path understood

---

## Ownership

Suggested ownership model:

- Data Platform = repo owner
- Semantic Architecture lead = semantic contract approver
- Data Engineering = implementation approver
- Platform Operations = deployment workflow approver
